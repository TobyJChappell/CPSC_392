# Assignment06
@name Toby Chappell  
@student_id 2312642  
@email tchappell@chapman.edu  
@course CPSC 392
@assignment 6

The program uses the built-in kMeans clustering algorithm to find the hidden genres in song data. It first uses the elbow method to  figure out how many genres there should be, and then comes up with a way to reduce the number of attributes being used for clustering. Following this, there is a lengthy note on how to validate the model.

Next is a implementation of k-Means algorithm. There are plenty of implementations for kMeans on the internet. The kMeans algorithm only uses the k value of 2 and can only be applied on 2 independent variables.