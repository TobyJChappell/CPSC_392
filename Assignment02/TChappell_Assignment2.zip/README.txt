Assignment02

@name Toby Chappell  
@student_id 2312642  
@email tchappell@chapman.edu  
@course CPSC 392
@assignment 2

The project is an exploratory data analysis of an NBA Elo dataset, including: reporting missing values and outliers, classifying numerical and categorical attributes, and plotting different combination of attributes to visualize relationships. The report on findings and visualizations is located under Assignment02.ipynb.
