# Assignment05

@name Toby Chappell  
@student_id 2312642  
@email tchappell@chapman.edu  
@course CPSC 392
@assignment 5

The program determines the best classifier on from k-Nearest Neighbors, Logistic Regression, and Decision Trees. The training testing split is a 80/20 split and the program reports the accuracy score for each model.

At the end of the code, there is a not about which classifier performed the best and as well as the advantages and disadvantages of each classifier.