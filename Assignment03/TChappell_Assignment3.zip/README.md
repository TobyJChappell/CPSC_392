# Assignment03

@name Toby Chappell  
@student_id 2312642  
@email tchappell@chapman.edu  
@course CPSC 392
@assignment 3

simple-regression.ipynb: Python program that computes the best-fit line for a set of data points using linear regression. The function outputs the best fit line “y = b0 + b1x”, the coefficient of determination (r2), and plots the data as a scatter plot along with the best fit line.

boston-regression.ipynb: Predicts the median value of homes (medv) in Boston using two linear regression models. The first uses lower status of population (lstat) as a single indpendent variable and the second uses lstat and the number of rooms (rm) as the independent variables. Models are validated using a 70/30 split and display the final R-squared value.
