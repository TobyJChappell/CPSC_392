# Assignment07
@name Toby Chappell
@student_id 2312642
@email tchappell@chapman.edu  
@course CPSC 392
@assignment 7

1) Create a dendrogram for set1.txt to find a cutoff distance value where all clusters are viewable. Next, cluster the data and show a scatter plot based with colored by the cluster labels using algomerative clustering.

2) Remove the quality attribute for winequality-red.csv, and run PCA to reduce the feature space to 2 features only. Next, create a dendrogram and use agglomerative clustering to find clusters in the data. Then, display a scatter plot of the 2 principal components, with points colored by their generated clusters.
